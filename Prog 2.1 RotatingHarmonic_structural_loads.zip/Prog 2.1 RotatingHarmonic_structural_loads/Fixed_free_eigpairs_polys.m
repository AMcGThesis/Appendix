function [f,y] = Fixed_free_eigpairs(Hz,y,x,w,g,l,E,I)
%global yout

O=Hz*2*pi;  % rad/s; omega, frequency.
wgl = w*g*l;
wg = w*g;
EI = E*I;
ln = 40; % How many extra terms do you want? (Solution precision)
Pl = 0;

tf = isa(x,'sym');
if tf == 1
Fxc = sym(zeros(1,4));
DFxc = sym(zeros(1,4));
D2Fxc = sym(zeros(1,4));
D3Fxc = sym(zeros(1,4));
sFn5 = sym(zeros(1,4));
sDFn5= sym(zeros(1,4));
sD2Fn5= sym(zeros(1,4));
sD3Fn5= sym(zeros(1,4));
end

for Oi = 1:length(O)
    for c = 0:3
        %F is a matrix where each cell represents "n" from n=0->n+8 and each
        %column represents "c" from c=0->c=3
    F{1+0}(:,c+1) = x.^c   ;                                       %n=0                                                                          %F1(x,c)
    F{1+1}(:,c+1) = zeros(length(x),1);                            %n=1                                                            %F2(x,c)
    F{1+2}(:,c+1) = -((wgl+Pl)/ (EI *((c+1)*(c+2)))) .*x.^(c+2);   %n=2                                  %F3(x,c)
    F{1+3}(:,c+1) =  ((wg*c)/(EI*((c+1)*(c+2)*(c+3)))) .*x.^(c+3) ;  %n=3                                 %F4(x,c)

    end
   for c = 0:3
        %F is a matrix where each cell represents "n" from n=0->n+8 and each
        %column represents "c" from c=0->c=3
    DF{1+0}(:,c+1) = c*x.^(c-1);                                          %n=0                                                                          %F1(x,c)
    DF{1+1}(:,c+1) = zeros(length(x),1)       ;                     %n=1                                                            %F2(x,c)
    DF{1+2}(:,c+1) = -(c+2)*((wgl+Pl)/ (EI *((c+1)*(c+2)))) .*x.^(c+1);   %n=2                                  %F3(x,c)
    DF{1+3}(:,c+1) =  (c+3)*((wg*c)  /(EI*((c+1)*(c+2)*(c+3)))) .*x.^(c+2);   %n=3                                 %F4(x,c)

   end
   for c = 0:3
        %F is a matrix where each cell represents "n" from n=0->n+8 and each
        %column represents "c" from c=0->c=3
    D2F{1+0}(:,c+1) = (c-1)*c*x.^(c-2)    ;                                      %n=0                                                                          %F1(x,c)
    D2F{1+1}(:,c+1) = zeros(length(x),1)    ;                        %n=1                                                            %F2(x,c)
    D2F{1+2}(:,c+1) = -(c+2)*(c+1)*((wgl+Pl)/ (EI *((c+1)*(c+2)))) .*x.^(c) ;  %n=2                                  %F3(x,c)
    D2F{1+3}(:,c+1) =  (c+2)*(c+3)*(wg*c)/(EI*((c+1)*(c+2)*(c+3))) .*x.^(c+1);   %n=3                                 %F4(x,c)

   end
   for c = 0:3
        %F is a matrix where each cell represents "n" from n=0->n+8 and each
        %column represents "c" from c=0->c=3
    D3F{1+0}(:,c+1) = (c-2)*(c-1)*c*x.^(c-3);                                          %n=0                                                                          %F1(x,c)
    D3F{1+1}(:,c+1) = zeros(length(x),1);                            %n=1                                                            %F2(x,c)
    D3F{1+2}(:,c+1) = -(c+2)*(c+1)*(c)*((wgl+Pl)/ (EI *((c+1)*(c+2)))) .*x.^(c-1) ;  %n=2                                  %F3(x,c)
    D3F{1+3}(:,c+1) =  (c+1)*(c+2)*(c+3)*(wg*c)/(EI*((c+1)*(c+2)*(c+3))) .*x.^(c) ;  %n=3                                 %F4(x,c)

   end
    %Loops to find the sum of Fn+5 from n=0->n=3 (because we're using a 4 soln
    %set) for each c from c=0-> c=3
        for c = 0:3
            for n = 0:ln
                for xi = 1:length(x)
                    %Find F_n+5 for each "c", which requires calculating Fn+3
                    %using the initial results generated.
                    F5_star(xi,n+1) = ( -(Pl + wgl)*(c+n+1)*(c+n+2)*F{n+3}(xi,c+1) ...
                                                     + (wg*(c+n+1)^2)*F{n+2}(xi,c+1)*x(xi) ...
                                                        + w*O(Oi)^2*F{n+1}(xi,c+1)*x(xi).^2 ) ...
                                      *( x(xi).^2 / (EI*((c+n+1)*(c+n+2)*(c+n+3)*(c+n+4)) )); 
                end
                F{n+5}(:,c+1) = F5_star(:,n+1) ;
                n
            end
                %Sum of F_n+5 for each "c" 
                 for ni = 0:ln
                    if ni == 0
                        sFn5(:,c+1) = zeros(length(x),1);
                    end
                sFn5(:,c+1) = F{ni+5}(:,c+1)+sFn5(:,c+1);
       
               end
        end



        Fxc(:,0+1) =        1 - ((wgl + Pl)*x.^2 / (2*EI))                                  + sFn5(:,1); %F(x,0)
        Fxc(:,1+1) =        x - ((wgl + Pl)*x.^3 / (6*EI))      + (wg*x.^4 / (24*EI))       + sFn5(:,2); %F(x,1)
        Fxc(:,2+1) =     x.^2 - ((wgl + Pl)*x.^4 / (12*EI))     + (wg*x.^5 / (30*EI))       + sFn5(:,3); %F(x,2)
        Fxc(:,3+1) =     x.^3 - ((wgl + Pl)*x.^5 / (20*EI))     + (wg*x.^6 / (40*EI))       + sFn5(:,4); %F(x,3)


    %DF
        for c = 0:3
            for n = 0:ln
                for xi = 1:length(x)
                    %Find DF_n+5 for each "c", which requires calculating Fn+3
                    %using the initial results generated.
                    DF5_star(xi,n+1) = F{n+5}(xi,c+1)*(c+n+4)./x(xi);
                end
                DF{n+5}(:,c+1) = DF5_star(:,n+1); 
            end
                %Sum of DF_n+5 for each "c" 
               for ni = 0:ln
                    if ni == 0
                        sDFn5(:,c+1) = zeros(length(x),1);
                    end
                sDFn5(:,c+1) = DF{ni+5}(:,c+1)+sDFn5(:,c+1);
       
               end
        end

        DFxc(:,0+1) =         -  (2*(wgl + Pl).*x    / (2*EI))                             + sDFn5(:,1); %DF(x,0)
        DFxc(:,1+1) =       1 -  (3*(wgl + Pl).*x.^2 / (6*EI))  + (4*wg.*x.^3 / (24*EI))   + sDFn5(:,2); %DF(x,1)
        DFxc(:,2+1) =    2.*x -  (4*(wgl + Pl).*x.^3 / (12*EI)) + (5*wg.*x.^4 / (30*EI))   + sDFn5(:,3); %DF(x,2)
        DFxc(:,3+1) = 3.*x.^2 -  (5*(wgl + Pl).*x.^4 / (20*EI)) + (6*wg.*x.^5 / (40*EI))   + sDFn5(:,4); %DF(x,3)

    %D2F
        for c = 0:3
            for n = 0:ln
                for xi = 1:length(x)
                    %Find D2F_n+5 for each "c", which requires calculating Fn+3
                    %using the initial results generated.
                    D2F5_star(xi,n+1) = F{n+5}(xi,c+1)*(c+n+3)*(c+n+4)./(x(xi)^2);
                end
                D2F{n+5}(:,c+1) = D2F5_star(:,n+1) ;
            end
                 %Sum of DF_n+5 for each "c" 
            for ni = 0:ln
                    if ni == 0
                        sD2Fn5(:,c+1) = zeros(length(x),1);
                    end
                sD2Fn5(:,c+1) = D2F{ni+5}(:,c+1)+sD2Fn5(:,c+1);
       
               end
        end

        D2Fxc(:,0+1) =        - (2* (wgl + Pl).*1    / (2*EI))                             + sD2Fn5(:,1); %D2F(x,0)
        D2Fxc(:,1+1) =        - (6* (wgl + Pl).*x    / (6*EI))  + (12*wg.*x.^2 / (24*EI))  + sD2Fn5(:,2); %D2F(x,1)
        D2Fxc(:,2+1) =      2 - (12*(wgl + Pl).*x.^2 / (12*EI)) + (20*wg.*x.^3 / (30*EI))  + sD2Fn5(:,3); %D2F(x,2)
        D2Fxc(:,3+1) =   6.*x - (20*(wgl + Pl).*x.^3 / (20*EI)) + (30*wg.*x.^4 / (40*EI))  + sD2Fn5(:,4); %D2F(x,3)


    %D3F
        for c = 0:3
            for n = 0:ln
                for xi = 1:length(x)
                    %Find D2F_n+5 for each "c", which requires calculating Fn+3
                    %using the initial results generated.
                    D3F5_star(xi,n+1) = -(wgl+Pl)*DF{n+3}(xi,c+1)/EI + wg*(c+n+1)*F{n+2}(xi,c+1)/EI + w*O(Oi)^2*F{n+1}(xi,c+1).*x(xi)/(EI*(c+n+1));
                end
                D3F{n+5}(:,c+1) = D3F5_star(:,n+1) ;
            end
               %Sum of DF_n+5 for each "c" 
               for ni = 0:ln
                    if ni == 0
                        sD3Fn5(:,c+1) = zeros(length(x),1);
                    end
                sD3Fn5(:,c+1) = D3F{ni+5}(:,c+1)+sD3Fn5(:,c+1);
       
               end
        end

        D3Fxc(:,0+1) =                                                                         + sD3Fn5(:,1) ;%D3F(x,0)
        D3Fxc(:,1+1) =        -    (6* (wgl + Pl)       / (6*EI))  + ( 24*wg.*x    / (24*EI))  + sD3Fn5(:,2) ;%D3F(x,1)
        D3Fxc(:,2+1) =        -    (24*(wgl + Pl).*x    / (12*EI)) + ( 60*wg.*x.^2 / (30*EI))  + sD3Fn5(:,3) ;%D3F(x,2)
        D3Fxc(:,3+1) =      6 -    (60*(wgl + Pl).*x.^2 / (20*EI)) + (120*wg.*x.^3 / (40*EI))  + sD3Fn5(:,4) ;%D3F(x,3)


f(Oi) = D2Fxc(end,2+1)*D3Fxc(end,3+1) - D3Fxc(end,2+1)*D2Fxc(end,3+1);

%Mode shape function for free-clamped beam

if tf == 1 %If symbolic
    A = polyval(sym2poly(D2Fxc(end,3+1)),l);
    B = polyval(sym2poly(D2Fxc(end,2+1)),l);
else
    A =  D2Fxc(end,3+1);
    B =  D2Fxc(end,2+1) ;  
end

y = Fxc(:,3+1) - (A/B)*Fxc(:,2+1);
end
% figure(100)
% plot(O,f)
yout=y;
freqs = f;
end

