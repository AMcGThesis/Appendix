%% Parameter Initialisation for Zebra
clc
clear all
close all
global ra ri
%Geometric
lb = 2.3;%m, wand length
do = .004%m, wand diameter
I = (pi/64)*do^4 % 2nd mom of area.

%Material
E = 45e9%210e9; %GPa, elastic modulus
ra = 0; %Viscous damping % (.02 = actual damping / critical damp)

rho = 2020; %kg/m^3
A = (pi/4)*do^2;
w=rho*A; %kg/m Beam weight
g=9.81;

%Modal Inclusions - Choice of number of modes to use between Hz_min and Hz_max.
Hz_min = 0; %Minimum freq. to find modes
Hz_max = 200; %Max freq. to find modes in 
rootslim = 6; %max number of modes
Hz = linspace(Hz_min,Hz_max,100*Hz_max); 

%Forcing
%Allows application of moment, concentrated load, or distributed load.
n_loads = 1;
O =    0% Forced frequency - one frequency only? Superposition should still work
F =    [] ;
zF =   [] ; %Locations associated with forces.
M =    []  ; %Conc moment magnitude
zM =   [] ; %Locations of conc. moments
W =    [1]  ; %Entries should be row vectors of polynomial coefficients.

%initialise
%i2=0; 
heightvec = 0 %If =/=0, a pinned support is applied some height up the beam
%%%%


for h = 1%:length(heightvec) %If sweeping multiple pinned support heights, this loop is used.
    
  
    l{h} = lb; %Set pole total length = bending length
    height = []; %ie, no double clamp for RH/Zebra in the gallery versions!
      x = transpose(linspace(0,l{h},100)); %How many points do you want to display in plotted answers? (100 - 1000 is a good range)
    if size(W) > [0]
            zW = l{h}*ones(1,length(W));
        else
            zW = [];
    end
    z = [zF,zM,zW]; %Vector of locations to to apply loads
    if size(height) > 0
        z(end+1) = height; %load application point for the pinned support - it's a conc. force.
    end
    
%% To evaluate the beam, we need to know the modeshapes. 
%To generate the modeshapes, we need to know the resonant frequencies.
   
%Generate resonant frequencies: root finder for a Fixed-Free beam
%(Naguleswaran, 1991)
    Y = w*g*l{h}^3 / (E*I); %Gravity parameter of wand being evaluated.
    fprintf('The Beam Gravity Parameter is Y = %.1f\n Upto %.0f roots are being found on \n the interval %.2f to %.2f Hz \n', Y,rootslim, Hz(1),Hz(end))
    for i = 1:length(Y)
        y = Y(i);
        [f]  = @(Hz) Fixed_free_eigpairs(Hz,y,x(end),w,g,l{h},E,I); %Function handle
        zf = Hz(f(Hz).*circshift(f(Hz),[0 -1]) <= 0); %Find approximate zero intercepts
        zf = zf(1:end-1); %remove any wrap around zeros
        fprintf('Approx roots found')
        for k1 = 1:length(zf)
            fz(k1) = fzero(f,zf(k1)); %zero finding algorithm
            k1
            if length(fz) == rootslim %break when I've found a certain number of roots
                break
            end
        end
        fprintf('exact roots found')
    fZ(:,i)=[0;fz'*(2*pi)]; % Turn into rad/s from Hz and tabulate
    clear fz
    end

    %% Create Polynomial representation of modeshapes
    %Generates modeshapes for integration
    %These need to be based on a given frequency and gravity parameter, or 
    %determined from the eigenvalue finder in step 1
    
    %Note: this takes time!
    syms X
    for i = 1:length(fZ)-1
        [~,V] = Fixed_free_eigpairs_polys(fZ(i+1)/(2*pi),Y,X,w,g,l{h},E,I); % Generate polynomial representation of modeshape.
        V = vpa(V); %Convert modeshape polynomial into vector form
        Vp(i,:) = sym2poly(V); %Convert modeshape polynomial into vector form
    end
    Vpvec{h} = Vp; %Store data
    
    %% Modeshape Scaling
    %Scale modeshapes to unity weighting at the end node
    for j = 1:length(Vp(:,1)) 
            Vpend(j) = polyval(Vp(j,:),l{h}); %
    end
    for i = 1:length(Vp(:,1))
            Vp(i,:) = Vp(i,:) / Vpend(i);
    end

    for i = 1:length(Vp(:,1))
        for j = 1:length(x)
            Vpe(i,j) = polyval(Vp(i,:),x(j));
        end
    end
    fZ
%% Greens functions / Loading
    for i2 = 1:1
        mode = input('Desired mode? (Usually 3 for Zebra):  ')
        O = fZ(mode+1)
        %Modeshapes were determined inside the Sliding_fixed_eigpairs function.
        %This code determines the modal weightings, a, for each mode subject to a
        %delta input at height 'z'. A given number of 'z's' represents a given number of
        %forces.
                    clear X
        %Goal:Determine the unknown coefficient for each mode, for each
        %load at desired (Resonant) Frequency
        %
        %Then: Superimpose loads  
       for k = 1:length(z)
            if k<=(length(zF)+length(zM))+length(zW) && k>(length(zF)+length(zM)) %...if we're dealing (uniform) distributed loads!
                kW = k - (length(zF)+length(zM));
                %Here, we're just going to directly evaluate the deflection,
                %otherwise there are too many poly's to deal with!!
                aW(kW,:) = Undetermined_coefficients_dist(O,Vp,fZ(2:end),x(i),w,g,l{h},E,I,x); %Determine modal weights for each element we want the deflection at!
                for j = 1:length(Vp(:,1))
                    G_starW(j,:) = aW(kW,j)*Vp(j,:); %Modal deflection polynomial for each delta.
                    XW(j,:)      = W(kW)*G_starW(j,:); % XW = conv(f(x),G(x)). Nice for polynoms! Assumes a load along the whole span. Get fancy with zW to alter this.
                    XW_tot       = sum(XW); %Add all the modes together to get total deflection polynomial
                end
                Xw = polyval(XW_tot,x);%Evaluate the poly to get the shape.
            end
       end
        X{i2} = Xw;
        
        %Scale amplitude to unity.
        scale{i2} = X{i2}(end);
        
        XXX{i2} = X{i2}/scale{i2}; %Normalised deflection of beam
        
        Mom_poly = -E*I*polyder(polyder(XW_tot))/scale{i2}; %Definition of moment from deflection
            Moment{i2} = polyval(Mom_poly,x); %Moment along beam
            
        Shear_poly = polyder(Mom_poly); %Definition of shear from deflection
            Shear{i2} = polyval(Shear_poly,x); %Shear force along beam

        Oindex(i2) = O %Index frequencies chosen for analysis.

    end
end
%% Output loop
%A apply performance amplitude to normalised data
Amp = [.325]; %Amplitude 3rd mode performances Zebra
%Loop to generate loads for a given amplitude (from the normalized data)
for i3 = 1
    S(i3) = Shear{i3}(1)*Amp(i3);
    M(i3) = Moment{i3}(1)*Amp(i3);
    Stress(i3) = Moment{i3}(1)*Amp(i3)*(do/2)/I;
end

fprintf('Zebra Structural Parameters \n***************************');
Freqs = Oindex/(2*pi)
S
M
Stress
fprintf('***************************');
plot(Amp(1)*XXX{i2},x,-Amp(1)*XXX{i2},x)
xlabel('deflection (m)')
ylabel('height (m)')
title('Evaluated beam form')