function [ mdot_air,mdot_LPG,P_air,P_LPG] = Isen_nozzle_flow_aug(dthroat)
%Isentropic Nozzle Flow equations to generate flow requirements for one
%nozzl.
%Note: assumes flow to each nozzle identical.

%Nozzle properties
    Qd = 1 ;                     %Discharge coefficient
    Athroat = (pi/4)*dthroat^2;  %Throat diameter
    M=1                          %Mach number
    
%Properties of LPG - a 60/40 mixtures of propane and butane. 
    R_prop= 188.56; %Source: engr. toolbox
    R_but = 143.05; %Source: engr toolbox

    y_prop = 1.13;
    y_but = 1.185; %N-butane = 1.18 / iso_butane = 1.19

    R_LPG = 0.6 * R_prop + 0.4*R_but %Specific gas constant
    y_LPG = 0.6*y_prop + 0.4*y_but   %ratio of specific heats
    mm_LPG = 0.4*58.122+0.6*44.1;    %Molar mass

%Properties of air
    R_air = 287;   %Specific gas constant
    y_air = 1.4;   %ratio of specific heats
    mm_air = 28.96;%Molar mass

%Mixed Properties of LPG + air
    Percent_LPG = .5 %50%
    Percent_air = 1-Percent_LPG %By mass.

    R = Percent_LPG*R_air + Percent_air*R_LPG; %average R
    y = Percent_LPG*y_air + Percent_air*y_LPG; %Average y
    P_mix = 101325*(2/(y+1))^(y/(y-1));

    P_LPG = P_mix/2.71;% The partial pressure
    P_air = P_mix-P_LPG;% The partial pressure
    P_air_abs = P_air+101325/2
    P_LPG_abs = P_LPG+101325/2


    P_mix_abs = P_mix+101325; %12PSI+atm
    T_mix = 293; %K (20deg C)


%Isentropic flow equation
mdot_nozzle =  (P_mix*Athroat/sqrt(T_mix)) * sqrt(y/R)*M*(1+((y-1)/2)*M^2)^(-(y+1)/(2*(y-1)));
mdot_total = mdot_nozzle; %for 20 nozzles

rho_tot = P_mix_abs / (R * T_mix); %density of the mixture
c = sqrt(y*(P_mix_abs)/rho_tot);%Speed of Sound assuming an ideal gas

Qdot = mdot_total/rho_tot; %Volumetric flow rate
mm_mix = (P_air/P_mix)*mm_air+(P_LPG/P_mix)*mm_LPG;

%Partial density from total by modifying to account for the a) the partial
%pressure of the gas, and b) the relative weight of the molecules in that
%pressure fraction. here the assumption is that pressure is proportional
%to mass flow.
rho_LPG = rho_tot *(P_LPG/P_mix)*mm_LPG/mm_mix; %partial density
rho_air = rho_tot *(P_air/P_mix)*mm_air/mm_mix; %partial density
mdot_LPG = rho_LPG*Qdot;
mdot_air = rho_air*Qdot;
