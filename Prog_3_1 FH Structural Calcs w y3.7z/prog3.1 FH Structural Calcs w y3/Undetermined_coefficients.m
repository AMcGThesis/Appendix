function [a] = Undetermined_coefficients(O,Vp,wn,z,w,g,l,E,I,x)

global ra ri
%Generate undetermined coefficients from generated modeshapes.

%input vars: mass/length, ang. freq (rads),aero damp, int.damp,
%flex.rigidity,gravity,length,length coord,modeshape matrix (column
%vecs),forcing location
for j = 1:length(Vp(:,1)) %For each modeshape
    DVp  = [0,polyder(Vp(j,:))];
    D2Vp = [0,0,polyder(DVp)];
    D3Vp = [0,0,0,polyder(D2Vp)];
    D4Vp = [0,0,0,0,polyder(D3Vp)];

    %process: take inner product between solution X(x) and each modeshape to
    %determine parallel part of solution. 
    %This simplifies to just be the modeshape function multiplied by itself!
    %Functional multiplication is the integral over the considered range (0->L)
    %Kinetic Energy
    Tp_star = -w*O^2*conv(Vp(j,:),Vp(j,:)); 
    Tp(j)   = diff(polyval(polyint(Tp_star),[0 l]));%Kinetic energy for each mode

    %Potential Energy
    Pp_star2 = polyadd(E*I*D4Vp, w*g*l*D2Vp,-conv([w*g*1 0],D2Vp),- w*g*DVp);
    Pp_star = conv(Pp_star2,Vp(j,:)); %Potential Energy for each mode
    Pp(j) =  diff(polyval(polyint(Pp_star),[0 l])); %Pot. energy each mode

    %"Modal Damping"
    %crit_damping = 2*sqrt(Tp(j)*Pp(j))
    
    
   % Cp_star = conv(1i*ra*O*Vp(j,:) + 1i*ri*O*D4Vp(j,:),Vp(j,:));
   if Tp(j) == 0 
        Cp(j) =0; % .02*(Tp(j)+Pp(j));%Cp(j) =  diff(polyval(polyint(Cp_star),[0 l])); %Damped. energy each mode
   else
        Cp(j) = 0;
   end
    %Forcing 
    Fp(j) = polyval(Vp(j,:),z);%conv(Vp(j,:),dirac(x-z)) %For a delta at a point 'z'
    %Fp_star = conv(Vp(j,:),1); %Magnitude '1' distributed load - here conv is just used as multiplication (same thing!)
    %Fp(j) = diff(polyval(polyint(Fp_star),[0 1]));
    %Fp(j) =  polyval(Vp(j,:),z) %Forcing energy each mode

    a(j) = (-Fp(j) /(Tp(j)+Cp(j)+Pp(j)));
    %solve(-a(j)*Tp +a(j)*Cp + a(j)*Pp + Fp == 0,a(j))
end

end