XP_tot = polyadd(XW_tot,XR_tot);

xi = linspace(0,1.5,1000)
l=xi(end)
for i4 = 1:length(XXX)
    f = @(xi) dispfunc(xi,XP_tot)
    loc(i4) = fzero(f,l)
    clear xi
end

%%
function [XXX2] = dispfunc(xi,XP_tot)
    XXX2 = polyval(XP_tot,xi)
end