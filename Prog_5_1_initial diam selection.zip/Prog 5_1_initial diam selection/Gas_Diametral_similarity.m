%% Similar diametral pair generation for Flaming Harmonic - GAS
clc
clear all

%% Gas specification%%%%%%%%%%%%%
y=1.6;           %Gravity parameter of Flaming Harmonic - gas filled / empty

%% Geometric and Structural property definitions
%Properties of scaled wand, using the 'test' parameters for an initial
%guess
l = 10;          %Test lengths for scaling
E=30e9;          %Pa Young's mod. (GFRP test wand)
p = 2020;        %kg/m^3 Desity (GFRP)
g = 9.81;        %m/s^2

%% Generate pairs of statically similar Diameters for the gas filled wand at y=1.6
tvec = [0:.5:10]*10^-3; % mm test wall thicknesses
syms di
hold on
for j = 0:1:length(tvec)-1
    i = tvec(j+1)
      R =  solve( y*E*(di+2*i)^2+y*E*di^2 == 16*p*g*l^3); %Roots of eqn (2.3.19)
      R = double(R);
      if imag(R(2)) <= .0001 && R(2)>=0 %(real+positive only)
            Di(j+1,1) = R(2);
            Do(j+1,1) = Di(j+1,1)+2*i;
      else
            Di(j+1,1) = 0;
            Do(j+1,1) = 0;      
    end
     t(j+1) = i;
end


%% plotting
figure(2)
hold on
plot(1000*tvec,1000*Do,'k',1000*tvec,1000*Di,'k --', 'linewidth',2)
set(gca,'FontSize',14)
grid on
xlabel('Scale Ratio [l/l_o]')
ylabel('Diameter [mm]')
legend('Empty Outer Diameter','Empty Inner Diameter')
