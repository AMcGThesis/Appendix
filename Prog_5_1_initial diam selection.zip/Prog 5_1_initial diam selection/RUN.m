%% Initial diameter selection for Flaming Harmonic with Test Wand Properties
%After evaluating as set of diametral pairs for both the gas and water
%performances, we plot both to help select a pair which agrees with both
%pairs

%The loaded output files are from Water_diam_sim and Gas_diam_sim.m in this
%directory
%You may run these programs individually, the result here is just the
%merged outputs in a single figure.

load('Gas_D_sim_output.mat') %Outputs of gas_diametral_similarity.m

    figure(2)
    hold on
    plot(1000*tvec,1000*Do,'k',1000*tvec,1000*Di,'k --', 'linewidth',2)


load('Water_D_sim_output.mat') %Outputs of Water_Diametral_similarity.m
    plot(1000*tvec,1000*Di,'--','color','#f242f5','LineWidth',2)
    plot(1000*tvec,1000*Do,'color','#f242f5','LineWidth',2)
    
%Plot options
    set(gca,'FontSize',14)
    grid on
    xlabel('Wall Thickness [mm]')
    ylabel('Diameter [mm]')
    legend('Empty Outer Diameter','Empty Inner Diameter','Filled Outer Diameter','Filled Inner Diameter')
    axis([2 10 30 80])

%Select diameters at the vertcal line of intersection


