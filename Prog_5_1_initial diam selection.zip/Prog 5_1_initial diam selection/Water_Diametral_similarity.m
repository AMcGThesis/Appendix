%% Similar diametral pair generation for Flaming Harmonic - Water
clc
clear all

%% Water Specification%%%%%%%%%%%%
y=3; %Gravity parameter of Flaming Harmonic - water filled
pw=1000 %kg/m^3
%% Geometric and Structural property definitions
%Properties of scaled wand, using the 'test' parameters for an initial
%guess
l = 10; %Test lengths for scaling
E=30e9; %Pa Young's mod. (GFRP test wand)
p = 2020; %kg/m^3 Desity (GFRP)
g = 9.81; %ms^2

%% Generate pairs of statically similar Diameters for the gas filled wand at y=3
tvec = [0.5:.5:10]*10^-3; % mm test wall thicknesses
syms do
hold on
for j = 0:1:length(tvec)-1
    i = tvec(j+1)
     R =  solve( (16*g*l^3*p)/(E*(do^2 + (do - 2*i)^2)) - y + (16*g*l^3*pw*(do - 2*i)^2)/(E*(do^4 - (do - 2*i)^4)) == 0); %Roots of equation 3.2.4
       R = double(R);
  Di(j+1,1) = 0;
      Do(j+1,1) = 0;  
      for k = 1:length(R)
          if abs(imag(R(k))) <= .0001 && R(k)>=0%(real+positive only)
               Do(j+1,1) = R(k);
               Di(j+1,1) = Do(j+1,1)-2*i;
          end      
      end
     t(j+1) = i;
end

%% plotting
figure(2)
hold on
plot(1000*tvec,1000*Di,'--','color','#f242f5','LineWidth',2)
plot(1000*tvec,1000*Do,'color','#f242f5','LineWidth',2)
set(gca,'FontSize',14)
grid on
xlabel('Wall Thickness [mm]')
ylabel('Diameter [mm]')
legend('Empty Outer Diameter','Empty Inner Diameter','Filled Outer Diameter','Filled Inner Diameter')
axis([2 10 30 80])
