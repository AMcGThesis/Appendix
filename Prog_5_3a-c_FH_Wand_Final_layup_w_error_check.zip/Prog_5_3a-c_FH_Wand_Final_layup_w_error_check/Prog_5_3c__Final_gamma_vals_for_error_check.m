%% Checking the error estimate for the final wand layup 
clc
clear all
close all

%% Diameters
%Properties of final layup generated in Prog 5.3a
l = 10;     %Wand length (m)
E=34.0e9    %Flex. modulus from prog 5.3a (bulk flex. modulus) GPa         27.37e9;%28.1e9;
g = 9.81;   %m/s^2
di=.042;    % GFRP internal diameter / external diam of hdpe GPa
dliner = .0276; %hdpe bore diameter
do_layup = .0604%From layup specifications in Prog 5.3a
%Test diameters
do=di + [0:.00001:.030];
pw    = 1000; %Water density kg/m^3
phdpe = 950;  %HDPE density kg/m^3
pgfrp = 2020; %GFRP density kg/m^3

%% Loop to test whether layup properties/diam meet error criterion
for i = 1:length(do)
    mu_full  = pw*(pi/4)*dliner^2 + pgfrp*(pi/4)*(do(i)^2-di^2) + phdpe*(pi/4)*(di^2-dliner^2); %mass contribs. from hdpe, glass
    mu_empty =                      pgfrp*(pi/4)*(do(i)^2-di^2) + phdpe*(pi/4)*(di^2-dliner^2); % ditto, with water.
    p_bulk = mu_empty /((pi/4)*(do(i)^2-di^2));    %bulk density for each layup note choice of ID and OD treats hdpe as an added mass.
    
    y_water(i) = mu_full*g*l^3/(E*(pi/64)*(do(i)^4-di^4));
    y_gas(i) = mu_empty*g*l^3/(E*(pi/64)*(do(i)^4-di^4)) ;
    Ytot(i) = y_water(i)+y_gas(i)-(1.6+3);
    if Ytot(i) < 0.001
        do = do(1:i); %break if tolerance is met
        break
    end
end

%% plotting Error curve
figure(2)
plot(do(1:length(Ytot)),Ytot,'k','linewidth',2)
ylabel('Distance from Desired \gamma values(\gamma_w + \gamma_g) - 4.6')
xlabel('Outer Diameter (mm)')
ylim([0 5])
grid minor
set(gca,'FontSize',18)
xlim([.045 .070])

%% printing outputs
fprintf('Parameters for an error minimised solution \n***************************');
fprintf('\n Ytot  %4.4f (This should be <.1)',Ytot(end)) 

Ytot(end)
fprintf('y_water') 
y_water(end)
fprintf('y_gas') 
y_gas(end)
fprintf('inner diameter (should be 42mm as selected)')
di
fprintf('Outer Diam desired by error criteria (m)') 
do(end)
fprintf('Outer diam chosen in layup (m)')
do_layup
fprintf('***************************');