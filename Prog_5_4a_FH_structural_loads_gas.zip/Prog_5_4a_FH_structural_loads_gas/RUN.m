%%  Operating loads of a Flaming Harmonic GAS performance, finalised properties.
%This program uses the standard procedure from chapter 4 to generate the
%vibratory form and loads of an equivalent cantilever. Then, the loads are modified to account
%for the flexible end condition in a loop at the end of this script
clc
clear all
close all
global ra ri

%Geometric
lb = 10;%m, wand length
do = .0604;%m, wand diameter
di = .042;
I = (pi/64)*(do^4-di^4); % 2nd mom of area for a rotating harmonic wand.

%Material properties from finalised wand layup - prog 5.3a
E = 34.0e9; %GPa, elastic modulus
ra = 0; %Viscous damping % 
ri = 0; %Shear rate damping
A = (pi/4)*(do^2-di^2);
w=3.79;%kg/m Beam weight
g=9.81; %m/s^2

%Modal Inclusions
Hz_min = 0; 
Hz_max = 200;
rootslim = 6; %max number of modes being hunted in range. Higher modes may get chopped.
Hz = linspace(Hz_min,Hz_max,100*Hz_max); %500 generates sufficient resolution for approximate zero finding. Maybe change if a large range of Hz is being handled? 

%Forcing
n_loads = 1;
O =    0;% Forced frequency - one frequency only? Superposition should still work
F =    [] ;
zF =   [] ; %Locations associated with forces.
M =    []  ; %Conc moment magnitude
zM =   [] ; %Locations of conc. moments
W =    [1]  ; %Entries should be row vectors of polynomial coefficients.

%%%% Vector of forcing locations of interest
i2 = 0;
heightvec = 0; %Set away from zero to enfore a pinned support some height up the beam
for h = 1;%:length(heightvec)
    l{h} = lb; %Set pole total length = bending length
    height = []; %ie, no double clamp for Zebra in the gallery version!
    %Solution resolution
    x = transpose(linspace(0,l{h},100)); %Solution is equation driven: how many points do you want to display in plotted answers? (100 - 1000 is a good range)
    Y = w*g*l{h}^3 / (E*I);

    if size(W) > [0]
        zW = l{h}*ones(1,length(W));
    else
        zW = [];
    end
    z = [zF,zM,zW];
    if size(height) > 0
        z(end+1) = height;
    end

    %%Naguleswaran Root Finder Fixed-Free beam
    fprintf('The Beam Gravity Parameter is Y = %.1f\n Upto %.0f roots are being found on \n the interval %.2f to %.2f Hz \n', Y,rootslim, Hz(1),Hz(end))
    %fZ = zeros(rootslim+1,length(Y));
    for i = 1:length(Y)
        y = Y(i);
        [f]  = @(Hz) Fixed_free_eigpairs(Hz,y,x(end),w,g,l{h},E,I); %Function handle
        zf = Hz(f(Hz).*circshift(f(Hz),[0 -1]) <= 0); %Find approximate zero intercepts
        zf = zf(1:end-1); %remove any wrap around zeros
        fprintf('Approx roots found')
        for k1 = 1:length(zf)
            fz(k1) = fzero(f,zf(k1)); %zero finding algorithm
            k1
            if length(fz) == rootslim %break when I've found a certain number of roots
                break
            end

        end
        fprintf('exact roots found')
    fZ(:,i)=[0;fz'*(2*pi)]; % Turn into rad/s from Hz and tabulate
    clear fz
    end
    %% Create Polynomial representation of functions
    %Generates Naguleswaran Modeshapes for integration
    %These need to be based on a given frequency and gravity parameter, or 
    %set of freqs and gammas, determined from the eigenvalue finder in step 1
    syms X
    for i = 1:length(fZ)-1
        [~,V] = Fixed_free_eigpairs_polys(fZ(i+1)/(2*pi),Y,X,w,g,l{h},E,I); % extract Modeshape
        V = vpa(V); %Convert modeshape polynomial into vector form
        Vp(i,:) = sym2poly(V); %Convert modeshape polynomial into vector form
    i
    end
    Vpvec{h} = Vp;
    %% Modeshape Scaling
    %Scaling Modeshapes to unity weighting at the end node
    for j = 1:length(Vp(:,1)) 
            Vpend(j) = polyval(Vp(j,:),l{h}); %
    end

    for i = 1:length(Vp(:,1))
            Vp(i,:) = Vp(i,:) / Vpend(i);
    end

    for i = 1:length(Vp(:,1))
        for j = 1:length(x)
            Vpe(i,j) = polyval(Vp(i,:),x(j));
        end
    end
    fZ
    for i2 = 1:1
        O = input('Set O for evaluation')
        %% Greens functions
        %Modeshapes were determined inside the Sliding_fixed_eigpairs function.
        %This code determines the modal weightings, a, for each mode subject to a
        %delta input at height 'z'. Any number of 'z's' represent any number of
        %forces.
        
        %Determine the unknown coefficient for each mode
        %Generates polynomials for each mode, for each forcing term!
        clear X
        % Evaluate pole at desired Resonant Frequency
       for k = 1:length(z)
            if k<=(length(zF)+length(zM))+length(zW) && k>(length(zF)+length(zM)) %...if we're dealing (uniform) distributed loads!
                kW = k - (length(zF)+length(zM));
                %Here, we're just going to directly evaluate the deflection,
                %otherwise there are too many poly's to deal with!!
                aW(kW,:) = Undetermined_coefficients_dist(O,Vp,fZ(2:end),x(i),w,g,l{h},E,I,x); %Determine modal weights for each element we want the deflection at!
                for  kk = 1:length(aW)
                    if kk ~= 2
                        aW(kk) = 0
                    end
                end
                
                for j = 1:length(Vp(:,1))
                    G_starW(j,:) = aW(kW,j)*Vp(j,:); %Modal deflection polynomial for each delta.
                    XW(j,:)      = W(kW)*G_starW(j,:); % XW = conv(f(x),G(x)). Nice for polynoms! Assumes a load along the whole span. Get fancy with zW to alter this.
                    XW_tot       = sum(XW); %Add all the modes together to get total deflection polynomial
                end
                Xw = polyval(XW_tot,x);%Evaluate the poly to get the shape.
            end
       end
        X{i2} = Xw;
        
        %Scale amplitude to unity.
        scale{i2} = X{i2}(end);
        XXX{i2} = X{i2}/scale{i2}; %Normalised deflection of beam
        Mom_poly = -E*I*polyder(polyder(XW_tot))/scale{i2};
            Moment{i2} = polyval(Mom_poly,x); %Moment along beam
            [pks,locs] = findpeaks(abs(Moment{i2}));
        Shear_poly = polyder(Mom_poly);
            Shear{i2} = polyval(Shear_poly,x); %Shear force along beam
        Oindex(i2) = O %Index critical frequencies chosen for analysis.

    end
end
%% Cantilever Properties
Amp = 1.4; %1.7m matches 'RH static similarity .17m/m
X_out{1} = Amp*XXX{1}

%Loop to generate loads for a given amplitude (from the normalized data)
do_biax = .064;
E_biax  = 15.2e9;

do_uniax= .062;
E_uniax = 38.0e9;

do_hdpe = .042;
E_hdpe = 1e9;

M = Moment{1}*Amp 
S = Shear{1}(1)*Amp; %Shear at given amplitude
K_base = M(1)*Amp/(-E*I);%Curvature at given amplitude
K_pole = (M(locs) / M(1))*K_base;
    
        Base_Stress_biax  = -E_biax * do_biax/2*K_base ;
        Base_Stress_uniax = -E_uniax* do_uniax/2*K_base;
        Base_Stress_hdpe  = -E_hdpe * do_hdpe/2*K_base;
        
        Pole_stress_biax  = -E_biax * do_biax/2*K_pole ;
        Pole_stress_uniax = -E_uniax* do_uniax/2*K_pole;
        Pole_stress_hdpe  = -E_hdpe * do_hdpe/2*K_pole;
        
        Pole_stress_uniax_SCF = 2.6*Pole_stress_uniax;
        
Ampratio = 373e6/Pole_stress_uniax_SCF %Amplitude reduction wrt rotating harmonic. 
Amplim = Ampratio*Amp %Maximum supportable amplitude (m/m)

%Output loop for basic properties (of cantilevered version)
fprintf('Gas Structural Parameters \n***************************');
Freqs = Oindex/(2*pi)
S_max = S*Ampratio %max shear at operating amplitude
M_base_max = M(1)*Ampratio %overturning moment at operating amplitude
Pole_stress_uniax_SCF_max = Pole_stress_uniax_SCF*Ampratio %
Base_stress_uniax_max     = Base_Stress_uniax*Ampratio
Amplim 
fprintf('Servicable tip amplitude, metres \n')
fprintf('*************************** \n');
figure
plot(X_out{1}*Ampratio,x,-X_out{1}*Ampratio,x)
title('Gas Wand')

% Modification for Flexible end conditions
fprintf('With lp=0.1lb \n***************************');

Amplim_lp = Amplim/(1-.02); %Increased amplitude (rather than increasing stress)

Stress_pole_lp = Pole_stress_uniax_SCF_max %So, pole stress is the same!
Stress_base_lp = (1-.32)*Base_stress_uniax_max*(Amplim_lp/Amplim)

S_max_lp = S_max *(Amplim_lp/Amplim) %Assume worst case shear from previous
M_base_max_lp = (1-.32)*M_base_max *(Amplim_lp/Amplim)  %Base stress

freq_lp  = (17.73/21.60)*Freqs %Gas wand speed
fprintf('***************************');
hold on
plot(X_out{1}*Ampratio*Amplim_lp/Amplim,x,-X_out{1}*Ampratio*Amplim_lp/Amplim,x)

