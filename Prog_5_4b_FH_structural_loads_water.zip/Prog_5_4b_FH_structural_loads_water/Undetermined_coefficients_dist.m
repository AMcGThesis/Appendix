function [a] = Undetermined_coefficients_dist(O,Vp,wn,z,w,g,l,E,I,x)

global ra ri
%Generate undetermined coefficients from generated modeshapes.

for j = 1:length(Vp(:,1)) %For each modeshape
    DVp(j,:)  = [0,polyder(Vp(j,:))];
    D2Vp(j,:) = [0,0,polyder(DVp(j,:))];
    D3Vp(j,:) = [0,0,0,polyder(D2Vp(j,:))];
    D4Vp(j,:) = [0,0,0,0,polyder(D3Vp(j,:))];

    %process: take inner product between solution X(x) and each modeshape to
    %determine parallel part of solution. 
    %This simplifies to just be the modeshape function multiplied by itself!
   %Kinetic Energy
    Tp_star = -w*O^2*conv(Vp(j,:),Vp(j,:)); 
    Tp(j)   = diff(polyval(polyint(Tp_star),[0 l]));%Kinetic energy for each mode

    Tp_star = -w*conv(Vp(j,:),Vp(j,:)); 
    Tp(j)   = diff(polyval(polyint(Tp_star),[0 l]));%Kinetic energy for each mode

    %Potential Energy
    Pp_star2 = polyadd(E*I*D4Vp(j,:), w*g*l*D2Vp(j,:),-conv([w*g*1 0],D2Vp(j,:)),- w*g*DVp(j,:));
    Pp_star = conv(Pp_star2,Vp(j,:)); %Potential Energy for each mode
    Pp(j) =  diff(polyval(polyint(Pp_star),[0 l])); %Pot. energy each mode

    %"Modal Damping"
    % Cp_star = conv(1i*ra*O*Vp(j,:) + 1i*ri*O*D4Vp(j,:),Vp(j,:));
   if Tp(j) == 0 
        Cp(j) =0; % .02*(Tp(j)+Pp(j));%Cp(j) =  diff(polyval(polyint(Cp_star),[0 l])); %Damped. energy each mode
   else
        Cp(j) = 0;
   end
    %Forcing 
    Fp(j) = diff(polyval(polyint(Vp(j,:)),[0,l]));%conv(Vp(j,:),dirac(x-z)) %For a delta at a point 'z'

    if j == 2
    a(j) = (-Fp(j) /(Tp(j)+Cp(j)+Pp(j)));
    else 
        a(j) = 0
    end
end

end