%Newland Params for Counterweighted-Countersprung mechanism
function [M,C,K,m,do,di,E,lt,EI] = Newland_params_WW(n,c,Mt)
%Initialising
M = zeros(n,n);
K=zeros(n,n);
C=zeros(n,n);
ma = zeros(n,1);
mb = zeros(n,1);
%%%%%%%%%%%%%

% Wand Parameters for original Water Whirler
g=9.81;   %gravity m/s^2
lt=10;    %Wand length m
E=25.1e9; %Flexural modulus of Water Whirler GPa 
do = .058;%m
di = .032;%m
Ax = (pi/4) * (do^2-di^2); %cross section area
mt=(1745*Ax+1000*(pi/4)*di^2)*lt;%Total wand Mass kg

I = (pi/64) * (do^4-di^4); %2nd moment of area
EI = E*I;%Flexural rigidity

m=mt/n; %mass per link kg/m
l=lt/n; %length per link m

k=E*I/l;    %spring constant for each link Nm/rad

%Base Parameters
Cb=0;% base damping Ns/m
Mb =100;%base mass kg
Kb =8000;%%base stiffness N/m
Lk=1; %Base lengh
%%%%%%%%%%%

%Mass Matrix
    for i = 1:n
        ma(i,1) = 1 + 2*(i-1);
        mb(i,1) = 4*(i-1);
    end
    mb(1) = 1;
    M(:,end) = ma;
    for i = 1:n-1
        M(i:end,end-i) = mb(1:end-i+1);
    end

%Stiffness Matrix
    kk =(2*k/(m*g*l));
    for i =1:n
        ka(i,1) = -1;
        kb(i,1) = -2;
    end
    ka(1) = kk-1;
    kb(1) = kk;
    kb(2) = -2*kk;
    kb(3) = kk-2;
    K(:,end) = ka;

    for i = 1:n-2
        K(i:end,end-i-1) = kb(1:end-i+1);
        K(i+1,end-i-1) = K(i+1,end-i-1) + ma(i+1);
    end
    K(:,end-1) = [kb(2:end);-2];
    K(1,end-1) = K(1,end-1)+1;

  
%Damping Matrix
for i = 1:n
    C(i,n-i+1)=1;
    if i <= n-1
    C(i,n-i)=-2;
    end
    if i <= n-2
    C(i,n-i-1)=1;
    end
end


%%%%%%%%%% Base parameters
K(end,1) =-2+( 4*(2/3)*Kb*Lk/(m*g));% + 2*Mb*nb/(m*Lb) ;% + K(end,1);% BASE SPRING STIFFENED
M(end,1) = M(end,1)+8*Mb*Lk/(m*l);
C(end,1)=C(end,1)+Cb;
%%%%%%%%%%%%%%%%

%Coefficients infront of matrix
M = (m*l/4)*M;
K = (m*g/2)*K;
C = (c/l)*C;
%%%

%Influence of end mass%%%%%%%%%%%%%%%%%%
for i = 1:n
    M(i,end) = M(i,end)+i*Mt*l; %adding end mass
end

for i = 1:n-1
    K(i,end-i) = K(i,end-i) - Mt*g;
end
    K(:,end) = K(:,end) + Mt*g;
end
%%%%%%%%%%%%%%%%%%%%%