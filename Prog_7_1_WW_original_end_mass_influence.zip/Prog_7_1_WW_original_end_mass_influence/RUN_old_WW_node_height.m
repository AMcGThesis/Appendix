%% ORIGINAL Water Whirler end mass response
%Predicts the node height along the NEW Water Whirler wand
%for a range of different end masses
clc
clear all
endmass = [0:1:10]; %kg
n = 100;  %elements in the beam

%Input forcing properties (Nominal only here!)
amplitude =1; %Tb Nm
frequency =1; %rad/s
w = 1;        %Duty cycle of force input
[acc, t] = modsquare(frequency, amplitude,w); %Input waveform - modsquare
acc=acc';
t=t';

%Zero padding input
dt = t(end)-t(end-1);
tadd = (t(end):dt:t(end)+50)';
acc = [acc ; zeros(length(tadd),1)];
time = [t ; tadd]';
N=length(time);
f=1/max(time):1/max(time):(N)/max(time);

%Frequency and forcing setup
O=2*pi*f; %Vector of frequencies for analysis.
vect= [zeros(n-1,1);1];
f = vect * acc'; %Generate vector of force inputs
for i = 1:n
    F(i,:)=fft(f(i,:)'); %Frequency domain 
end
%%%%%%%%%%%%%
clear f

%% Loop to run through endmasses
for KK = 1:length(endmass) 
    clear X1 Xd1 Xdd1 TF1 X Xd Xdd V
    
    %parameters are generated in Newland Params
    c = 120;
    [M,C,K,m,do,di,E,l,EI] = Newland_params_oldWW(n,c,endmass(KK));
    %%%%%%%%%%%%
    
    %Generate transfer function
    for i = 1:length(O)/2
        TF=inv(-O(i)^2.*M+1i.*C.*O(i)+K);
        X1(:,i)=TF*F(:,i);
        Hmag(i)=norm(TF);
    end
    
    %Frequency response
    X=zeros(n,length(acc));
    for i = 2:length(X1)
        X(:,i) = X1(:,i); %First element of X1 == first element of X1
        X(:,length(acc)-i+2) = conj(X1(:,i)); %First element of X1 is equal to last element
    end
    %%%%%%%%%%%%%%%%%%%
    
    endmass(KK) %Just print to show progress.

    [~,resfreq] = findpeaks(Hmag);%Eigenvalues from H - within tolerance of O
if resfreq(1) > 50
    [~,locs] = findpeaks (-abs(real( X(:,resfreq(1))/X(end,resfreq(1)) ))); %inspect form of modeshaps and find node heights
else
    [~,locs] = findpeaks (-abs(real( X(:,resfreq(2))/X(end,resfreq(2)) ))); %inspect form of modeshaps and find node heights
end
    l = linspace(0,l,n);
    Store(KK) = l(locs(end));
  

end
% 

%% Output loop
%
Store_total = Store;
endmass_total = endmass;

%Make a quadratic data fit for the end mass vector
[quad_fit]=fit(endmass_total',Store_total','poly2')
[quad_fit_eval] = feval(quad_fit,endmass_total')
%%%%%

%Plotting
figure(24601)
hold on
plot(endmass_total,10*quad_fit_eval,'k -','Linewidth',2)
plot([0 10],[74 74],'--','color','#f242f5','linewidth',1.25)
plot([0 10],[82 82],'--','color','#f242f5','linewidth',1.25)
plot(endmass_total,Store_total*10,'k +')

xlabel('End Mass on Water Whirler (kg)')
ylabel('Node Height up Wand at Resonance (%)')
ylim([68 85])
legend('Node height (Quadratic fit)', ...
    'Aesthetic acceptability limits')
set(gca,'FontSize',18)
grid minor