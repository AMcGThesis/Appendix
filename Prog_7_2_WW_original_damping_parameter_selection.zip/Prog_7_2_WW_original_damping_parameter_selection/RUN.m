%% ORIGINAL Water Whirler Damping Constant
%Predicts the damping ratio caused by an input value of the damping
%parameter "c" for each link
clc
clear all

% Inputs
c = [.0001,logspace(1,2.8,25)] %Desired link damping constants
n = 100;  %elements in the beam
O=2*pi*[0:.00154:200];%Range of frequencies to evaluate (rad/s)

%Loop to iterate through damping constants
for II = 1:length (c) 
    clear f
    II %Just to show progress
    
    %Parameter generation
    [M,C,K,m,do,di,E,l,EI] = Newland_params_oldWW(n,c(II));
    %%%%%%%%%%%%

    %Generate transfer function
    for i = 1:length(O)/2
        TF=inv(-O(i)^2.*M+1i.*C.*O(i)+K);
        Hmag(i)=norm(TF);
    end
    close all
    Hmag2{II} = Hmag; %Store Transfer function in a loop.
end
%% Transfer functions plot for each damping param. evaluated
figure 
for II = 1:length(c)
    semilogy(O(1:round(length(O)/5)),Hmag2{II}(1:round(length(O)/5)),'linewidth', 2);
    hold on
end
ylabel('Transfer Function Y(s)/T(s)')
xlabel(' Frequency (rad/s)')
set(gca,'FontSize',18)
grid minor
axis([0 20 .0001 10])

%% Q-Factor path to Damping Ratio
%For each loop, evaluate the damping ratio of the desired resonance peak
for II = 1:length(c)
    %Find peaks of the transfer function
    [Hp(II),locs(II)] = findpeaks(Hmag2{II}(500:1100));
    Hr2(II) = (1/sqrt(2))*Hp(II);%bandwidth
    
    %Using a cubic representation of the resonance peak to find the bandwidth
    estimate = fit(O(500:1100)',Hmag2{II}(500:1100)'-Hr2(II),'cubicinterp');
    w1 = fzero(estimate,[5,O(locs(II)+499)]);
    w2 = fzero(estimate,[O(locs(II)+499),10]);
    
   Q(II) = O(locs(II)+499) / (w2-w1); %Q factor 
   Z(II) = 1/(2*Q(II)); %Estimate of damping ratio from Q factor
end

%% plotting output
figure
plot(c(1:length(Z)),Z,'linewidth',2)
ylabel('Damping Ratio \zeta_2')
xlabel('Damping Constant "c" (Nms/rad)')
set(gca,'FontSize',18)
grid minor
xlim([0 600])