%% Run to present a comparison of WW and RH modeshapes during a performance
load('WW_for_plot.mat')
figure
subplot(1,2,1)
    plot(.667*X(:,149)/X(end,149),l,'k',-.667*X(:,149)/X(end,149),l,'k','linewidth',2)
    xlabel('Amplitude (m)')
    ylabel('Height (m)')
    axis([-1.2 1.2 0 10])
    set(gca,'FontSize',18)
    legend('Original Water Whirler')
    grid minor
%%
clear all
load('FP-2-3.mat')
for i3 = [1,11,21,31,41,51];
xi{i3} = linspace(0,1+heightvec(i3),1000);
xi{i3} = xi{i3}-heightvec(i3)
end
subplot(1,2,2)
plot(XXX{1},10*xi{1},'k',-XXX{1},10*xi{1},'k','linewidth',2)
axis([-1.2 1.2 0 10])
legend('Lyes Harmonic, \gamma = 1.6')
    set(gca,'FontSize',18)
    grid minor
    xlabel('Amplitude (m)')