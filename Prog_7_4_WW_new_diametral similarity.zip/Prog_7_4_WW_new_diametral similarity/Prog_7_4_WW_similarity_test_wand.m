%% Program to find a geometric specification for a replacement Water Whirler
%Generates an initial guess for the geometric sizing of a new wand,
%using the test wand properties, before a layup is generated using CLT
clc
clear all
close all

%generated using the 'test wand' properties

l = 10; %desired wand length
y=3.1;%To match original Water Whirler
%Test wand properties
E=30e9; %Pa Young's mod. (GFRP test wand)
p = 2020; %kg/m^3 Desity (GFRP)
g = 9.81; %ms^2
pw = 1000 %kg/m^3 water density


tvec = [.0001:.0002:.025]; %Wall thickness range considered m
%% Statically similar pairs
%Loop to generate statically similar diameter pairs at test thickness
syms di do l
for j = 0:1:length(tvec)-1
    i = tvec(j+1); %i is the in loop thickness variable
    l = 10;
    R =  solve( (16*g*l^3*p)/(E*(do^2 + (do - 2*i)^2)) - y + (16*g*l^3*pw*(do - 2*i)^2)/(E*(do^4 - (do - 2*i)^4)) == 0); %Static similarity criterion for fluid filled wands
    R = double(R);
    Di(j+1) = 0;
    Do(j+1) = 0;
    
    for k = 1:length(R)
        if abs(imag(R(k))) <= .0001 && R(k)>=0 %Select only real, positive roots
            Do(j+1) = R(k);
            Di(j+1) = Do(j+1)-2*i;
        end
    end
    t(j+1) = i;
    I(j+1) = (pi/64)*(Do(j+1)^4-Di(j+1)^4); %Inertia of generated section
    mu(j+1) = pw*(pi/4)*Di(j+1)^2+p*(pi/4)*(Do(j+1)^2-Di(j+1)^2); %Self weight of generated section
    
end

%% Plotting outputs
figure (1)
hold on
plot(t*10^3,Do*10^3,'k -','LineWidth',2)
plot(t*10^3,Di*10^3,'k --','LineWidth',2)
plot(t*10^3, 27.3*ones(length(t),1),'k -.','LineWidth',2)
ylim([0 100])
ylabel('Diameter (mm)')
xlabel('Wall Thickness (mm)')
set(gca,'FontSize',18)
grid on

yyaxis right
plot(t*10^3, mu,'color','#f242f5','LineWidth',2)
ax = gca;
ax.YAxis(2).Color = '#f242f5';
ylim([0 20]);
ylabel('Self Weight (kg/m)')
legend('Outer Diameter','Inner Diameter','Minimum bore diameter','Self Weight')

%% Original WW gravity parameter
%%uncomment if desired
% l = 10
% p = 1745
% g = 9.81
% pw = 1000
% do = .058
% di = .032
% E = 25.15e9
% Ax = (pi/4) * (do^2-di^2); %cross section area
% I = (pi/64) * (do^4-di^4); %2nd moment of area
% mu=(p*Ax+pw*(pi/4)*di^2);%p * lt * Ax; %Total Mass
%
% y_og = mu*g*l^3 / (E*I)
%
