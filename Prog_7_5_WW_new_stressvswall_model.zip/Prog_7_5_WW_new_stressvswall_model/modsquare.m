function [torque, time] = modsquare(frequency, amplitude,w)
%Modified square wave generator given wave frequency, amplitude, and cycle 'on' time.
%Input frequency = rad/s, amplitude is a torque, typically the base torque, applied when the cycle is 'on'

%Setting basic sample resolution
samplerate = 200;
nomtime = linspace(0, .9150*50, 	50*samplerate);

%Switching logic between + and - pulses
wave = zeros(1,length(nomtime));
    for i = 1:length(nomtime)
        n = floor(nomtime(i));
        if nomtime(i) - n <= w
            wave(i) = 1;
        end
    end

%Setup time vector
time = nomtime / 2;
time = time/frequency;

%Waveform
torque = amplitude*square(2*pi*frequency*time).*wave;


%Padding torque and time vectors with zeros.
torque=[zeros(1,.1*length(torque)), torque,zeros(1,.1*length(torque))];
startpad =0 : (time(2)-time(1)) : time(round(length(time)/10)) ;
time = [startpad,time(2)+(time+startpad(end))];
time = [time,time(end)+startpad];