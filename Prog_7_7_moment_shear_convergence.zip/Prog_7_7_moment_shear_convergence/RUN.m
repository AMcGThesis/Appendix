%% Moment and Shear convergence of data for the new Water Whirler wand.
clc
clear all
nm = linspace(5,100,25); %Vary number of links used to assess convergence

%Input forcing
amplitude =1; %Tb Nm
frequency =1; %Hz
w = 1;        %Duty cycle of force input
[torque, t] = modsquare(frequency, amplitude,w); %Input waveform - modsquare
torque=torque';
t=t';

%Zero padding input
dt = t(end)-t(end-1);
tadd = (t(end):dt:t(end)+100)';
torque = [torque ; zeros(length(tadd),1)];
time = [t ; tadd]';
N=length(time);
f=1/max(time):1/max(time):(N)/max(time);

%Frequency and forcing setup
c = 120; %Nsm/rad
O=2*pi*f; %Vector of frequencies for analysis.
%Loop to iterate through the number of links, to generate the slope/curvature/shear slope for load evaluation
for KK = 1:length(nm)     
    clear X1 Xd1 Xdd1 TF1 F X Xd Xdd V
    n = round(nm(KK)) %elements in the beam
    
    vect= [zeros(n-1,1);1];
    
    %Generate frequency domain forcing
    f = vect * torque';
    for i = 1:n
        F(i,:)=fft(f(i,:)');
    end
    clear f
    
    %parameters are generated inside 'newland params'
    [M,C,K,m,do,di,E,l,EI] = Newland_params_WW(n,c);

    %Generate transfer function
    for i = 1:length(O)/2
        TF=inv(-O(i)^2.*M+1i.*C.*O(i)+K);
        X1(:,i)=TF*F(:,i);
        Hmag(i)=norm(TF);
    end
    X=zeros(n,length(torque));
    
    %Modal displancements
    for i = 2:length(X1)
        X(:,i) = X1(:,i); %First element of X1 == first element of X1
        X(:,length(torque)-i+2) = conj(X1(:,i)); %First element of X1 is equal to last element
    end
    
    l=linspace(0.0,l,n); %node locations along wand.
    
    %Identify 2nd mode peak
    [~,locs] = findpeaks(Hmag);%Eigenvalues from H - within tolerance of O
    if locs(1) < 40
        loc = locs(2);
    else
        loc = locs(1);
    end
    index(:,KK) = loc;
    
    %Store spatial derivatives to compute moment/shear afterwards.
    V = real(X(:,loc)/X(end,loc));
    V = 0.8*V / min(V);
    vdx{KK} = gradient(V,(l(2))); %Min(V) is the antinode; the belly width.
    vddx{KK} = gradient(vdx{KK},(l(2)));
    vdddx{KK} = gradient(vddx{KK},(l(2)));
    L{KK} = l;
end
%% Forces 
%Note, the operating loads are unscaled. 
for KK = 1:length(nm)
    Spk(KK) = max(abs(real(vdddx{KK}(3:end)))); %Peak shear force
    Mpk(KK) = max(abs(real(vddx{KK}())));       %Peak bending moment
end

%Normalise shear and moment
for KK = 1:length(nm)
    Srel(KK) = 100*Spk(KK) / Spk(end);
    Mrel(KK) = 100*Mpk(KK) / Mpk(end);
end

%Relative difference between previous and current iteration results.
for KK = 2:length(nm)-1
    Sreld(KK) = abs((Srel(KK)-Srel(KK-1)));
    Mreld(KK) = abs((Mrel(KK)-Mrel(KK-1)));
end

%% Plotting outputs
figure
hold on
plot(nm(2:end),Sreld,nm(2:end),Mreld,'linewidth',2)
xlabel('Number of Links (N)')
ylabel('Relative Difference (%)')
set(gca,'fontsize',18)
legend('Change in Peak Shear ','Change in Peak Moment')