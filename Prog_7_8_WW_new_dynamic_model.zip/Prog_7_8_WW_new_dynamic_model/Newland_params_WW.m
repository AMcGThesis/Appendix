%Newland Params for Counterweighted-Countersprung mechanism

function [M,C,K,freq,m,do,di,E,lt,EI] = Newland_params_WW(n,c)
%Initialising
M = zeros(n,n);
K=zeros(n,n);
C=zeros(n,n);
ma = zeros(n,1);
mb = zeros(n,1);
%%%%%%%%%%%%%


%Wand Parameters
g=9.81; %grav.
lt=10;%1.28%10;%12; %length
%p =2700 %7850%3340;%2400; %kg/m^3
E=28.1e9;%200e9%35e9;%35e9
do =.0565;%0.0028%4%0.0645;% 0.05; % m , OD
di =.0424;%0.00%25%0.0438;% 0.04;  % m , ID

Ax = (pi/4) * (do^2-di^2); %cross section area
I = (pi/64) * (do^4-di^4); %2nd moment of area

EI = E*I;
mt=(2020*Ax+1000*(pi/4)*di^2)*lt;%p * lt * Ax; %Total Mass
m=mt/n;
l=lt/n;

freq=4.694^2*sqrt(E*I/(mt*lt^3))/(2*pi);
%keyboard

k=E*I/l;    %EI/l
%Base Parameters

Cb=0;%40%40%20%75
Mb =100;%0%150; %150%150 %77 %77 %61%251%base mass
Kb =8050;%8190%6400%819%0%11000%7519%10000;%7519 %base stiffness
Lk=1;
Mt=3;
%%%
%%%%%%%%%%%

%Mass Matrix
    for i = 1:n
        ma(i,1) = 1 + 2*(i-1);
        mb(i,1) = 4*(i-1);
    end
    mb(1) = 1;
    M(:,end) = ma;
    for i = 1:n-1
        M(i:end,end-i) = mb(1:end-i+1);
    end

  %Stiffness Matrix
    kk =(2*k/(m*g*l));
    for i =1:n
        ka(i,1) = -1;
        kb(i,1) = -2;
    end
    ka(1) = kk-1;
    kb(1) = kk;
    kb(2) = -2*kk;
    kb(3) = kk-2;
    K(:,end) = ka;

    for i = 1:n-2
        K(i:end,end-i-1) = kb(1:end-i+1);
        K(i+1,end-i-1) = K(i+1,end-i-1) + ma(i+1);
    end
    K(:,end-1) = [kb(2:end);-2];
    K(1,end-1) = K(1,end-1)+1;

  
%Damping Matrix
%c=1000;
for i = 1:n
    C(i,n-i+1)=1;
    if i <= n-1
    C(i,n-i)=-2;
    end
    if i <= n-2
    C(i,n-i-1)=1;
    end
end


%%%%%%%%%% Base parameters
K(end,1) =-2+( 4*(2/3)*Kb*Lk/(m*g));% + 2*Mb*nb/(m*Lb) ;% + K(end,1);% BASE SPRING STIFFENED
M(end,1) = M(end,1)+8*Mb*Lk/(m*l);
C(end,1)=C(end,1)+Cb;

%%%%%%%%%%%%%%%%



M = (m*l/4)*M;
K = (m*g/2)*K;
C = (c/l)*C;
for i = 1:n
    M(i,end) = M(i,end)+i*Mt*l; %adding end mass
end

for i = 1:n-1
    K(i,end-i) = K(i,end-i) - Mt*g;
end
    K(:,end) = K(:,end) + Mt*g;
end
