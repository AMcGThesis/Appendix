%% New Water Whirler Dynamic Performance
clc
clear all
n = 100;  %elements in the beam

%Input forcing - chosen to obta
amplitude =363;         %Tb Nm
frequency =6.75/(2*pi); %Hz
w = .4;                 %Duty cycle of force input
[torque, t] = modsquare(frequency, amplitude,w); %Input waveform - modsquare
torque=torque';
t=t';

%Zero padding input
dt = t(end)-t(end-1);
tadd = (t(end):dt:t(end)+100)';
torque = [torque ; zeros(length(tadd),1)];
time = [t ; tadd]';
N=length(time);
f=1/max(time):1/max(time):(N)/max(time);

%Frequency and forcing setup
O=2*pi*f; %Vector of frequencies for analysis.
vect= [zeros(n-1,1);1]; %Apply force to pivot at base
f = vect * torque'; %Generate vector of force inputs
for i = 1:n
    F(i,:)=fft(f(i,:)'); %Frequency domain forcing
end
clear f

%parameters are generated inside 'newland params'
c=120; %Nsm/rad
[M,C,K,m,do,di,E,l,EI] = Newland_params_WW(n,c);


N=length(time);
f=1/max(time):1/max(time):(N)/max(time);
O=2*pi*f;

vect= [zeros(n-1,1);1];
f = vect * torque';
for i = 1:n
    F(i,:)=fft(f(i,:)');
end
clear f
[M,C,K,freq,m,do,di,E,l,EI] = Newland_params_WW(n,c); %generate parameters

%Generate transfer function
for i = 1:length(O)/2
    TF=inv(-O(i)^2.*M+1i.*C.*O(i)+K);
    X1(:,i)=TF*F(:,i);
    Hmag(i)=norm(TF);
end
X=zeros(n,length(torque));

%Modal displacements
for i = 2:length(X1)
    X(:,i) = X1(:,i); %First element of X1 == first element of X1
    X(:,length(torque)-i+2) = conj(X1(:,i)); %First element of X1 is equal to last element
end

%Time inversion
for i = 1:n
    x(i,:)=ifft(X(i,:));
end
close all
l=linspace(0.0,l,n);

%%  Forcing
%This requires scaling and application of SCF's etc as may be required
% V = real(X(:,143));
% vdx = gradient(V / min(V),(l(2))); %Slope
% vddx = gradient(vdx,(l(2)));       %Moment
% vdddx = gradient(vddx,(l(2)));     %Shear
% L = l;
%     Spk = max(abs(real(vdddx(3:end))));
%     Mpk = max(abs(real(vddx())));
%
% Shearpk_base = EI*Spk; %From definition of shear
% Momentpk = EI*Mpk;     %from definition of moment
%
% Shearpk_base
% Moment_base = EI*vddx(3)
% Stresspk = Momentpk*do / (2*(EI/E))

%% Plotting dynamics
figure(8)
subplot(3,1,1)
plot(time(1:length(x(end,:))),x(end,:),'k', 'linewidth', 1.5)
ylabel('Wand Tip Motion (m)')
xlim([0 35])
ylim([-1 1])
set(gca,'FontSize',13)

subplot(3,1,2)
ylabel('Drive Mech. Tilt Angle (deg)')
ylim([-20 20])
set(gca,'FontSize',13)
hold on
plot(time,atand(x(1,:)/l(2)),'k', 'linewidth', 1.5);
xlim([0 35])

subplot(3,1,3)
ylabel('Input Waveform (Nm)')
xlabel('Time (s)')
set(gca,'FontSize',13)
hold on
plot(time,torque,'k', 'linewidth', 1.5);
xlim([0 35])

%% Animated Figure
%%Uncomment if you wish to generate an animated figure. Double de-comment to save a gif
%%file to your computer, which may be very, very slow.
figure(72)
for i = 1:length(l)
    h = animatedline('maximumnumpoints', 250');
end
title('')
xlabel('Deflection (m)')
ylabel('Height(m)')
axis([-2 2 0 11])
pbaspect([3 13 1])
xfl = flipud(x);
lfl = fliplr(l);
for k = 1400:1:20000
    xvec = [x(:,k);xfl(:,k)];
    lvec = [l,lfl];
    addpoints(h,real(xvec),lvec);
    drawnow
    k;
    %              % draw stuff
    %     frame = getframe(gcf);
    %     img =  frame2im(frame);
    %     [img,cmap] = rgb2ind(img,256);
    %     if k == 2000
    %         imwrite(img,cmap,'animation.gif','gif','LoopCount',Inf);
    %     else
    %         imwrite(img,cmap,'animation.gif','gif','WriteMode','append');
    %     end
end