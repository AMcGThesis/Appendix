%% Parameter Initialisation for Zebra
clc
clear all
close all
global ra ri
%Geometric
lb = 1.28;%m, wand length
do = .0028%m, wand diameter
I = (pi/64)*do^4 % 2nd mom of area for a rotating harmonic wand.

%Material
E = 210e9%210e9; %GPa, elastic modulus
ra = 0; %Viscous damping % (.02 = actual damping / critical damp)
ri = 0; %Shear rate damping
%Y = 0;%[-100,-50,-10,-5,-4,-3,-2,-1,0,1,2,3,4,5,6,7,10,20,30,40,50,100,120,140];
rho = 7850%7800; %kg/m^3
A = (pi/4)*do^2;
w=rho*A; %kg/m Beam weight
g=9.81;

%Modal Inclusions
Hz_min = 0; 
Hz_max = 200;
rootslim = 6; %max number of modes being hunted in range. Higher modes may get chopped.
Hz = linspace(Hz_min,Hz_max,100*Hz_max); %500 generates sufficient resolution for approximate zero finding. Maybe change if a large range of Hz is being handled? 

%Forcing
n_loads = 1;
O =    0% Forced frequency - one frequency only? Superposition should still work
F =    [] ;
zF =   [] ; %Locations associated with forces.
M =    []  ; %Conc moment magnitude
zM =   [] ; %Locations of conc. moments
W =    [1]  ; %Entries should be row vectors of polynomial coefficients.

%%%% Vector of forcing locations of interest
i2 = 0
heightvec = 0 %Set away from zero to enfore a pinned support some height up the beam
for h = 1%:length(heightvec)
    l{h} = lb; %Set pole total length = bending length
    height = []; %ie, no double clamp for Zebra in the gallery version!
    %Solution resolution
    x = transpose(linspace(0,l{h},100)); %Solution is equation driven: how many points do you want to display in plotted answers? (100 - 1000 is a good range)
    Y = w*g*l{h}^3 / (E*I);

    if size(W) > [0]
        zW = l{h}*ones(1,length(W));
    else
        zW = [];
    end
    z = [zF,zM,zW];
    if size(height) > 0
        z(end+1) = height;
    end

    %%Naguleswaran Root Finder Fixed-Free beam
    fprintf('The Beam Gravity Parameter is Y = %.1f\n Upto %.0f roots are being found on \n the interval %.2f to %.2f Hz \n', Y,rootslim, Hz(1),Hz(end))
    %fZ = zeros(rootslim+1,length(Y));
    for i = 1:length(Y)
        y = Y(i);
        [f]  = @(Hz) Fixed_free_eigpairs(Hz,y,x(end),w,g,l{h},E,I); %Function handle
        zf = Hz(f(Hz).*circshift(f(Hz),[0 -1]) <= 0); %Find approximate zero intercepts
        zf = zf(1:end-1); %remove any wrap around zeros
        fprintf('Approx roots found')
        for k1 = 1:length(zf)
            fz(k1) = fzero(f,zf(k1)); %zero finding algorithm
            k1
            if length(fz) == rootslim %break when I've found a certain number of roots
                break
            end

        end
        fprintf('exact roots found')
    fZ(:,i)=[0;fz'*(2*pi)]; % Turn into rad/s from Hz and tabulate
    clear fz
    end
    %% Create Polynomial representation of functions
    %Generates Naguleswaran Modeshapes for integration
    %These need to be based on a given frequency and gravity parameter, or 
    %set of freqs and gammas, determined from the eigenvalue finder in step 1
    syms X
    for i = 1:length(fZ)-1
        [~,V] = Fixed_free_eigpairs_polys(fZ(i+1)/(2*pi),Y,X,w,g,l{h},E,I); % extract Modeshape
        V = vpa(V); %Convert modeshape polynomial into vector form
        Vp(i,:) = sym2poly(V); %Convert modeshape polynomial into vector form
    i
    end
    Vpvec{h} = Vp;
    %% Modeshape Scaling
    %Scaling Modeshapes to unity weighting at the end node
    for j = 1:length(Vp(:,1)) 
            Vpend(j) = polyval(Vp(j,:),l{h}); %
    end

    for i = 1:length(Vp(:,1))
            Vp(i,:) = Vp(i,:) / Vpend(i);
    end

    for i = 1:length(Vp(:,1))
        for j = 1:length(x)
            Vpe(i,j) = polyval(Vp(i,:),x(j));
        end
    end
    fZ
    for i2 = 1:1
        O = input('Set O for evaluation')
        %% Greens functions
        %Modeshapes were determined inside the Sliding_fixed_eigpairs function.
        %This code determines the modal weightings, a, for each mode subject to a
        %delta input at height 'z'. Any number of 'z's' represent any number of
        %forces.
        
        %Determine the unknown coefficient for each mode
        %Generates polynomials for each mode, for each forcing term!
        clear X
        % Evaluate pole at desired Resonant Frequency
       for k = 1:length(z)
            if k<=(length(zF)+length(zM))+length(zW) && k>(length(zF)+length(zM)) %...if we're dealing (uniform) distributed loads!
                kW = k - (length(zF)+length(zM));
                %Here, we're just going to directly evaluate the deflection,
                %otherwise there are too many poly's to deal with!!
                aW(kW,:) = Undetermined_coefficients_dist(O,Vp,fZ(2:end),x(i),w,g,l{h},E,I,x); %Determine modal weights for each element we want the deflection at!
                for j = 1:length(Vp(:,1))
                    G_starW(j,:) = aW(kW,j)*Vp(j,:); %Modal deflection polynomial for each delta.
                    XW(j,:)      = W(kW)*G_starW(j,:); % XW = conv(f(x),G(x)). Nice for polynoms! Assumes a load along the whole span. Get fancy with zW to alter this.
                    XW_tot       = sum(XW); %Add all the modes together to get total deflection polynomial
                end
                Xw = polyval(XW_tot,x);%Evaluate the poly to get the shape.
            end
       end
        X{i2} = Xw;
        
        %Scale amplitude to unity.
        scale{i2} = X{i2}(end);
        XXX{i2} = X{i2}/scale{i2}; %Normalised deflection of beam
        Mom_poly = -E*I*polyder(polyder(XW_tot))/scale{i2};
            Moment{i2} = polyval(Mom_poly,x); %Moment along beam
        Shear_poly = polyder(Mom_poly);
            Shear{i2} = polyval(Shear_poly,x); %Shear force along beam

        Oindex(i2) = O %Index critical frequencies chosen for analysis.

    end
end

Amp = [.175]; %Amplitude for 2nd and 3rd mode performances of Rotating Harmonic respectively
%Loop to generate loads for a given amplitude (from the normalized data)
for i3 = 1:1
    S(i3) = Shear{i3}(1)*Amp(i3);
    M(i3) = Moment{i3}(1)*Amp(i3);
    Stress(i3) = Moment{i3}(1)*Amp(i3)*(do/2)/I;
end

%%Output loop
fprintf('RH Structural Parameters \n***************************');
Freqs = Oindex/(2*pi)
S
M
Stress
fprintf('***************************');