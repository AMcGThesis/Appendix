%% Parameter Initialisation
clc
clear all
close all
global ra ri
%Geometric
%l = 1.28;%m, wand length
%do = .0028%m, wand diameter
I = 1%(.2*.0018^3)/12 %m^4, (pi/64)*do^4 % 2nd mom of area for a rotating harmonic wand.

%Material
E = 1%210e9; %GPa, elastic modulus
ra = 0; %Viscous damping % (.02 = actual damping / critical damp)
ri = 0; %Shear rate damping
%Y = 0;%[-100,-50,-10,-5,-4,-3,-2,-1,0,1,2,3,4,5,6,7,10,20,30,40,50,100,120,140];
rho = 1%7800; %kg/m^3
A = 1%(.2*.0018);%.2*.0018%(pi/4)*do^2;
w=1%rho*A; %kg/m Beam weight
g=1.6%9.81;%-9.81;%9.81;

%Modal Inclusions
Hz_min = 0; 
Hz_max = 150;
rootslim = 9; %max number of modes being hunted in range. Higher modes may get chopped.
Hz = linspace(Hz_min,Hz_max,100*Hz_max); %500 generates sufficient resolution for approximate zero finding. Maybe change if a large range of Hz is being handled? 

%Forcing
n_loads = 1;
O =    0%5*sqrt(E*I/(w*l^4)); %Forced frequency - one frequency only? Superposition should still work
F =    [] ;
zF =   [] ; %Locations associated with forces.
M =    []  ; %Conc moment magnitude
zM =   [] ; %Locations of conc. moments
W =    [1]  ; %Entries should be row vectors of polynomial coefficients.

%%%% Vector of forcing locations of interest
%%%%
i2 = 0
heightvec = 0:.01:.5;
for h = 1:length(heightvec)
    if h ==1
        height = [];
        l{h+1} = 1;
    else 
        height=heightvec(h)
        l{h+1} = 1+heightvec(h);
    end
%Solution resolution
x = transpose(linspace(0,l{h+1},1000)); %Solution is equation driven: how many points do you want to display in plotted answers? (100 - 1000 is a good range)
Y = w*g*l{h+1}^3 / (E*I);

if size(W) > [0]
    zW = l{h+1}*ones(1,length(W));
else
    zW = [];
end
z = [zF,zM,zW];
if size(height) > 0;
    z(end+1) = height;
end

%%Naguleswaran Root Finder Fixed-Free beam
fprintf('The Beam Gravity Parameter is Y = %.1f\n Upto %.0f roots are being found on \n the interval %.2f to %.2f Hz \n', Y,rootslim, Hz(1),Hz(end))
%fZ = zeros(rootslim+1,length(Y));
for i = 1:length(Y)
    y = Y(i);
    [f]  = @(Hz) Pinned_free_eigpairs(Hz,y,x(end),w,g,l{h+1},E,I); %Function handle
    zf = Hz(f(Hz).*circshift(f(Hz),[0 -1]) <= 0); %Find approximate zero intercepts
    zf = zf(1:end-1); %remove any wrap around zeros
fprintf('Approx roots found')
    for k1 = 1:length(zf)
        fz(k1) = fzero(f,zf(k1)); %zero finding algorithm
        k1
        if length(fz) == rootslim %break when I've found a certain number of roots
            break
        end

    end
    fprintf('exact roots found')
fZ(:,i)=[0;fz'*(2*pi)]; % Turn into rad/s from Hz and tabulate
clear fz
end
%% Create Polynomial representation of functions

%Generates Naguleswaran Modeshapes for integration
%These need to be based on a given frequency and gravity parameter, or 
%set of freqs and gammas, determined from the eigenvalue finder in step 1
syms X
for i = 1:length(fZ)-1
    [~,V] = Pinned_free_eigpairs_polys(fZ(i+1)/(2*pi),Y,X,w,g,l{h+1},E,I); % extract Modeshape
    V = vpa(V); %Convert modeshape polynomial into vector form
    Vp(i,:) = sym2poly(V); %Convert modeshape polynomial into vector form
i
end
%% Modeshape Scaling
%Scaling Modeshapes to unity weighting at the end node
for j = 1:length(Vp(:,1)) 
        Vpend(j) = polyval(Vp(j,:),l{h+1}); %
end

for i = 1:length(Vp(:,1))
        Vp(i,:) = Vp(i,:) / Vpend(i);
end

for i = 1:length(Vp(:,1))
    for j = 1:length(x)
        Vpe(i,j) = polyval(Vp(i,:),x(j));
    end
end
% figure(3)
% plot(Vpe,x) %Plot scaled modeshapes

%% Greens functions
%Modeshapes were determined inside the Sliding_fixed_eigpairs function.
%This code determines the modal weightings, a, for each mode subject to a
%delta input at height 'z'. Any number of 'z's' represent any number of
%forces.

%Determine the unknown coefficient for each mode
    %Generates polynomials for each mode, for each forcing term!
    clear X
    i2 = i2+1
    counter=0;
    for O = 0:.5:1000;
        counter = counter+1;
        for k = 1:length(z)
            if k<=(length(zF)+length(zM))+length(zW) && k>(length(zF)+length(zM)) %...if we're dealing (uniform) distributed loads!
                kW = k - (length(zF)+length(zM));
                %Here, we're just going to directly evaluate the deflection,
                %otherwise there are too many poly's to deal with!!
                aW(kW,:) = Undetermined_coefficients_dist(O,Vp,fZ(2:end),x(i),w,g,l{h+1},E,I,x); %Determine modal weights for each element we want the deflection at!
                for j = 1:length(Vp(:,1))
                    G_starW(j,:) = aW(kW,j)*Vp(j,:); %Modal deflection polynomial for each delta.
                    XW(j,:)      = W(kW)*G_starW(j,:); % XW = conv(f(x),G(x)). Nice for polynoms! Assumes a load along the whole span. Get fancy with zW to alter this.
                    XW_tot       = sum(XW); %Add all the modes together to get total deflection polynomial
                end
                Xw = polyval(XW_tot,x);%Evaluate the poly to get the shape.
            end
        end

            %Midspan pinned support
            %Is a reaction force at some height up the beam
           if size(height) > [0]
               a_midspan = Undetermined_coefficients(O,Vp,fZ(2:end),height,w,g,l{h+1},E,I,x); %Determine modal weights for each delta
                    for i = 1:length(Vp(:,1))
                        G_star_height(i,:) = a_midspan(i)*Vp(i,:); %Modal deflection polynomial for each delta.
                    end
                    G_star_height_tot = sum(G_star_height);
                    X_midspan = polyval(G_star_height_tot,x); %Xf = conv(Fd(x-z),G(x))
                R = -polyval(XW_tot,height) / polyval(G_star_height_tot,height);
                XR_tot = R*G_star_height_tot;
                XR = polyval(XR_tot,x);
            else
                XR = 0;
                XR_tot = 0;
            end
            XX = XR+Xw;
            Hmag{i2}(counter) = abs(XX(end));
            Omag{i2}(counter) = O;
    end
    figure(i2) %Generate figure to choose 2nd mode frequency
    [~,locs] = findpeaks(Hmag{i2});
    %plot(Omag{i2}/(2*pi),Hmag{i2});
   if length(locs) >= 2
    O = Omag{i2}(locs(1))%testfreq*(2*pi);
   else
    keyboard
   end
    clear locs
    % Evaluate pole at desired Resonant Frequency
       for k = 1:length(z)
            if k<=(length(zF)+length(zM))+length(zW) && k>(length(zF)+length(zM)) %...if we're dealing (uniform) distributed loads!
                kW = k - (length(zF)+length(zM));
                %Here, we're just going to directly evaluate the deflection,
                %otherwise there are too many poly's to deal with!!
                aW(kW,:) = Undetermined_coefficients_dist(O,Vp,fZ(2:end),x(i),w,g,l{h+1},E,I,x); %Determine modal weights for each element we want the deflection at!
                for j = 1:length(Vp(:,1))
                    G_starW(j,:) = aW(kW,j)*Vp(j,:); %Modal deflection polynomial for each delta.
                    XW(j,:)      = W(kW)*G_starW(j,:); % XW = conv(f(x),G(x)). Nice for polynoms! Assumes a load along the whole span. Get fancy with zW to alter this.
                    XW_tot       = sum(XW); %Add all the modes together to get total deflection polynomial
                end
                Xw = polyval(XW_tot,x);%Evaluate the poly to get the shape.
            end
        end

        %Midspan pinned support
        %Is a reaction force at some height up the beam
        if size(height) > [0]
            a_midspan = Undetermined_coefficients(O,Vp,fZ(2:end),height,w,g,l{h+1},E,I,x); %Determine modal weights for each delta
                for i = 1:length(Vp(:,1))
                    G_star_height(i,:) = a_midspan(i)*Vp(i,:); %Modal deflection polynomial for each delta.
                end
                G_star_height_tot = sum(G_star_height);
                X_midspan = polyval(G_star_height_tot,x); %Xf = conv(Fd(x-z),G(x))
            R = -polyval(XW_tot,height) / polyval(G_star_height_tot,height);
            XR_tot = R*G_star_height_tot;
            XR = polyval(XR_tot,x);
        else
            XR = 0;
            XR_tot = 0;
        end
        X{i2} = XR+Xw;
        %Scale amplitude to unity.
        scale{i2} = X{i2}(end);
        XXX{i2} = X{i2}/scale{i2};
%           plot(X,x)
%           title('Deflection')    
    d2XW = polyder(polyder(XW_tot));
    d2XR = polyder(polyder(XR_tot));
            Curvature = polyval(d2XW,x)+polyval(d2XR,x);
            %Apply scale factor to moment
            Moment{i2}    = -E*I*Curvature/scale{i2};
            M(i2) = max(abs(Moment{i2}));
            if length(height) ==0
                heightindex(i2) = 0
            else
            heightindex(i2) = height;
            end
            Oindex(i2) = O
            
    clear fz fZ zf y V Vp Vpe Vpend k1
end

figure(1000)
for i3 = 1:length(Moment)
plot(Moment{i3},x)
hold on
end
title('PP, 2nd mode')
figure(2000)
for i4 = 1:length(XXX)
plot(XXX{i4},x,-XXX{i4},x)
hold on
end
title('PP, 2nd mode')

fprintf('PP, 2nd mode')