function [XXX2] = dispfunc(x,XP_tot)
    XXX2 = polyval(XP_tot,x)
end