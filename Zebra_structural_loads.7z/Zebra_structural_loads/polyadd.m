function [added_polys] = polyadd(varargin)
%POLYADD takes a list of N row polynomials of the form [b,c;d,e,f] =
%[bx+c;dx^2,ex+f] and adds them together.
%Polyadd is useful when the number of coefficients in one polynomial is
%greater or lesser than the other polynomials

  %disp("Number of input arguments: " + nargin);
N = length(varargin);
  
  for i = 1:N
      L(i) = length(varargin{i}); %Inspect polynomial length
  end
  
M = max(L); %Define highest order polynomial 

for i = 1:N
    if length(varargin{i}) < M
        P(i,:) = [zeros(1,M-length(varargin{i})),varargin{i}]; %Pad shorter polynomials with leading zeros to allow addition
    else
        P(i,:) = varargin{i};
    end
end
    added_polys = sum(P); %Sum sums column vectors
    
end

